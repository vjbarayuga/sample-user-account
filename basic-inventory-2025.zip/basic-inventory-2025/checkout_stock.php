<?php 
include 'config/db.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
$user = $_SESSION['user'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $items = $_POST['items']; // Fetch items from the form

    foreach ($items as $item) {
        $stock_id = (int) $item['stock_id'];
        $quantity = (int) $item['quantity'];

        $check = $conn->prepare("SELECT quantity FROM stocks WHERE id = ?");
        $check->bind_param("i", $stock_id);
        $check->execute();
        $result = $check->get_result();
        $stock = $result->fetch_assoc();

        if ($stock && $stock['quantity'] >= $quantity) {
            $update = $conn->prepare("UPDATE stocks SET quantity = quantity - ? WHERE id = ?");
            $update->bind_param("ii", $quantity, $stock_id);
            $update->execute();

            $log = $conn->prepare("INSERT INTO stock_logs (stock_id, action, quantity) VALUES (?, 'OUT', ?)");
            $log->bind_param("ii", $stock_id, $quantity);
            $log->execute();
        } else {
            $error = "Not enough stock for item ID: " . $stock_id;
        }
    }

    if (!isset($error)) {
        header("Location: index.php");
        exit;
    }
}

$items = $conn->query("SELECT stocks.id, stocks.name, stocks.quantity, categories.name AS category FROM stocks JOIN categories ON stocks.category_id = categories.id");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Checkout Stock</title>
  <meta charset="UTF-8">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">📦 InventorySys</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"
      aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Inventory</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_stock.php">Add Stock</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="checkout_stock.php">Checkout Stock</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="stock_history.php">Stock History</a>
        </li>
      </ul>
      <span class="navbar-text me-3 text-white">
        👤 <?= htmlspecialchars($user['username']) ?> (<?= htmlspecialchars($user['role']) ?>)
      </span>
      <a href="logout.php" class="btn btn-outline-light">Logout</a>
    </div>
  </div>
</nav>

<!-- ✅ Page Content -->
<div class="container py-5">
  <h2>Checkout Stock</h2>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST">
    <div id="itemsContainer">
      <div class="mb-3 itemRow">
        <label class="form-label">Item</label>
        <select name="items[0][stock_id]" class="form-select" required>
          <option value="">Select item</option>
          <?php while ($item = $items->fetch_assoc()): ?>
            <option value="<?= $item['id'] ?>"><?= $item['name'] ?> (<?= $item['category'] ?> - Qty: <?= $item['quantity'] ?>)</option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="mb-3 itemRow">
        <label class="form-label">Quantity to Checkout</label>
        <input type="number" name="items[0][quantity]" class="form-control" min="1" required>
      </div>
    </div>

    <button type="button" class="btn btn-secondary" id="addItemBtn">Add Another Item</button>
    <button type="submit" class="btn btn-warning">Checkout</button>
    <a href="index.php" class="btn btn-secondary">Back</a>
  </form>
</div>

<!-- ✅ Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Handle adding new items dynamically
  document.getElementById('addItemBtn').addEventListener('click', function() {
    const container = document.getElementById('itemsContainer');
    const newItemRow = document.createElement('div');
    newItemRow.classList.add('mb-3', 'itemRow');
    newItemRow.innerHTML = `
      <label class="form-label">Item</label>
      <select name="items[${container.children.length}][stock_id]" class="form-select" required>
        <option value="">Select item</option>
        <?php
        $items = $conn->query("SELECT stocks.id, stocks.name, stocks.quantity, categories.name AS category FROM stocks JOIN categories ON stocks.category_id = categories.id");
        while ($item = $items->fetch_assoc()):
        ?>
          <option value="<?= $item['id'] ?>"><?= $item['name'] ?> (<?= $item['category'] ?> - Qty: <?= $item['quantity'] ?>)</option>
        <?php endwhile; ?>
      </select>
      <label class="form-label">Quantity to Checkout</label>
      <input type="number" name="items[${container.children.length}][quantity]" class="form-control" min="1" required>
    `;
    container.appendChild(newItemRow);
  });
</script>

</body>
</html>
