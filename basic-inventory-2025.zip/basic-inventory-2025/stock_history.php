<?php
include 'config/db.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Stock Logs</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">📦 InventorySys</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"
      aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Inventory</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_stock.php">Add Stock</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="checkout_stock.php">Checkout Stock</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="stock_history.php">Stock History</a>
        </li>
      </ul>
      <span class="navbar-text me-3 text-white">
        👤 <?= htmlspecialchars($user['username']) ?> (<?= htmlspecialchars($user['role']) ?>)
      </span>
      <a href="logout.php" class="btn btn-outline-light">Logout</a>
    </div>
  </div>
</nav>

<!-- ✅ Page Content -->
<div class="container py-5">
  <h2>Stock Activity Log</h2>
  <a href="index.php" class="btn btn-secondary mb-3">Back to Dashboard</a>

  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>Item</th><th>Category</th><th>Action</th><th>Quantity</th><th>Timestamp</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $logs = $conn->query("
        SELECT s.name AS stock_name, c.name AS category_name, l.action, l.quantity, l.timestamp
        FROM stock_logs l
        JOIN stocks s ON s.id = l.stock_id
        JOIN categories c ON s.category_id = c.id
        ORDER BY l.timestamp DESC
      ");

      while ($log = $logs->fetch_assoc()):
      ?>
        <tr>
          <td><?= htmlspecialchars($log['stock_name']) ?></td>
          <td><?= htmlspecialchars($log['category_name']) ?></td>
          <td><?= htmlspecialchars($log['action']) ?></td>
          <td><?= htmlspecialchars($log['quantity']) ?></td>
          <td><?= htmlspecialchars($log['timestamp']) ?></td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- ✅ Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
