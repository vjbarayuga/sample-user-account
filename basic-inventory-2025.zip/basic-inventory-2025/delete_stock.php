<?php
include 'config/db.php';
$id = (int) $_GET['id'];

$conn->prepare("DELETE FROM stock_logs WHERE stock_id = ?")->bind_param("i", $id)->execute();
$conn->prepare("DELETE FROM stocks WHERE id = ?")->bind_param("i", $id)->execute();

header("Location: index.php");
exit;
