<?php
include 'config/db.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
$user = $_SESSION['user'];

$id = $_GET['id'];

$result = $conn->prepare("SELECT * FROM stocks WHERE id = ?");
$result->bind_param("i", $id);
$result->execute();
$stock = $result->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $quantity = (int)$_POST['quantity'];
    $category_id = (int)$_POST['category'];

    $update = $conn->prepare("UPDATE stocks SET name=?, description=?, quantity=?, category_id=? WHERE id=?");
    $update->bind_param("ssiii", $name, $description, $quantity, $category_id, $id);
    $update->execute();

    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit Stock</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">📦 InventorySys</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"
      aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Inventory</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_stock.php">Add Stock</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="checkout_stock.php">Checkout Stock</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="stock_history.php">Stock History</a>
        </li>
      </ul>
      <span class="navbar-text me-3 text-white">
        👤 <?= htmlspecialchars($user['username']) ?> (<?= htmlspecialchars($user['role']) ?>)
      </span>
      <a href="logout.php" class="btn btn-outline-light">Logout</a>
    </div>
  </div>
</nav>

<!-- ✅ Page Content -->
<div class="container py-5">
  <h2>Edit Stock</h2>
  <form method="POST">
    <input type="text" name="name" class="form-control mb-2" value="<?= htmlspecialchars($stock['name']) ?>" required>
    <textarea name="description" class="form-control mb-2"><?= htmlspecialchars($stock['description']) ?></textarea>
    <input type="number" name="quantity" class="form-control mb-2" value="<?= $stock['quantity'] ?>" required>

    <select name="category" class="form-select mb-2">
      <?php
      $categories = $conn->query("SELECT * FROM categories");
      while ($cat = $categories->fetch_assoc()):
      ?>
        <option value="<?= $cat['id'] ?>" <?= $cat['id'] == $stock['category_id'] ? 'selected' : '' ?>>
          <?= htmlspecialchars($cat['name']) ?>
        </option>
      <?php endwhile; ?>
    </select>

    <button class="btn btn-primary">Update</button>
    <a href="index.php" class="btn btn-secondary">Cancel</a>
  </form>
</div>

<!-- ✅ Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
